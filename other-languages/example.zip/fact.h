#ifndef FACT_H
#define FACT_h
int fact(int n);
#endif